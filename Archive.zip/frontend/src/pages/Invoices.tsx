import React from 'react'; export default function Invoices(){ return <div><h1>Invoices</h1><p>Invoice UI</p></div>; }
