#!/usr/bin/env bash
mkdir -p ./uploads/receipts ./uploads/invoices ./uploads/bills
chmod -R 0775 ./uploads
echo created uploads
